Synthetic independent transparency and frame-order fixture.
