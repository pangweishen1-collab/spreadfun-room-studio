/* Small dependency-free state/packaging check. Browser layout QA is still required. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const html = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8');
const script = fs.readFileSync(path.join(__dirname, 'tool-page.js'), 'utf8');
class Element {
  constructor() { this.dataset = {}; this.attributes = {}; this.listeners = {}; this.value = ''; this.hidden = false; this.classList = {add(){},remove(){}}; }
  setAttribute(name,value) { this.attributes[name] = String(value); }
  getAttribute(name) { return this.attributes[name] ?? null; }
  removeAttribute(name) { delete this.attributes[name]; }
  addEventListener(name,callback) { this.listeners[name] = callback; }
  querySelector(selector) { this.children ??= {}; return this.children[selector] ??= new Element(); }
  click() { this.listeners.click?.({currentTarget:this,target:this}); }
  focus() { active = this; }
  showModal() { this.open = true; }
  close() { this.open = false; this.listeners.close?.(); }
}
const elements = new Map();
const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]);
assert.equal(new Set(ids).size,ids.length,'HTML IDs must be unique');
ids.forEach(id => elements.set(id,new Element()));
const translated = ['i18n','i18n-aria','i18n-alt'].map(attribute => [...html.matchAll(new RegExp(`data-${attribute}="([^"]+)"`,'g'))].map(match => {
  const element = new Element();
  element.dataset[attribute.replace(/-([a-z])/g,(_,letter) => letter.toUpperCase())] = match[1];
  return element;
}));
const languageButtons = ['zh','en'].map(language => { const button = new Element(); button.dataset.language = language; return button; });
const timers = new Map();
let active = null;
let serial = 0;
let revoked = [];
const document = {
  title:'',documentElement:{lang:'zh-CN'},getElementById:id => elements.get(id),addEventListener(){},
  querySelectorAll:selector => selector === '[data-language]' ? languageButtons : translated[['[data-i18n]','[data-i18n-aria]','[data-i18n-alt]'].indexOf(selector)] || []
};
elements.get('output-name').value = 'my-asset';
const window = {setTimeout:callback => { const id = ++serial; timers.set(id,callback); return id; },clearTimeout:id => timers.delete(id),addEventListener(){}};
const sandbox = { document,window,URL:{createObjectURL:() => 'blob:local-preview',revokeObjectURL:url => revoked.push(url)},Image:class{},console };
vm.runInNewContext(script,sandbox,{filename:'tool-page.js'});
const demo = window.ToolPageDemo;
assert.equal(demo.getState(),'empty');
assert.equal(elements.get('generate-button').disabled,true);
for (const state of ['ready','processing','success','error','empty']) {
  demo.setState(state);
  assert.equal(elements.get('main').dataset.state,state);
  assert.equal(elements.get('download-button').disabled ?? true,true,'No pretend downloadable result');
}
demo.setState('ready');
demo.simulateGeneration();
assert.equal(demo.getState(),'processing');
assert.equal(elements.get('generate-button').getAttribute('aria-busy'),'true');
assert.equal(elements.get('output-name').disabled,true);
assert.equal(timers.size,1);
const complete = [...timers.values()][0];
complete();
assert.equal(demo.getState(),'success');
assert.equal(elements.get('generate-button').disabled,false);
elements.get('output-name').listeners.input();
assert.equal(demo.getState(),'ready','Changing parameters invalidates the sample result');
elements.get('output-name').value = ' ';
demo.simulateGeneration();
assert.equal(demo.getState(),'ready');
assert.equal(elements.get('output-name').getAttribute('aria-invalid'),'true');
assert.equal(active,elements.get('output-name'));
demo.setLanguage('en');
assert.equal(document.documentElement.lang,'en');
assert.equal(elements.get('filename-hint').textContent,'Enter a file name to run the demo.');
assert.equal(elements.get('output-name').getAttribute('aria-invalid'),'true','Language changes preserve invalid state');
assert.equal(elements.get('output-name').value,' ','Language changes preserve entered parameters');
demo.setLanguage('zh');
assert.equal(elements.get('filename-hint').textContent,'填写文件名称后再演示。','Error explanation survives switching languages in both directions');
demo.setState('processing');
elements.get('cancel-button').click();
assert.equal(demo.getState(),'ready');
assert.equal(active,elements.get('generate-button'));
assert.equal(timers.size,0);
assert.throws(() => demo.setState('unknown'),/Unknown tool state/);
for (const source of html.matchAll(/(?:src|href)="([^"]+)"/g)) {
  if (!source[1].startsWith('https:') && !source[1].startsWith('#')) assert.ok(fs.existsSync(path.join(__dirname,source[1])),`Missing local file: ${source[1]}`);
}
assert.ok(!/<a\b[^>]*\bdownload(?:\s|=|>)/.test(html),'Demo must not advertise a fake file download');
console.log('Passed: five states, busy/cancel, parameter invalidation, validation, languages, local assets and no fake downloads.');
