# Fun Toolkit · 空状态与动效包 v1.0

打开 index.html 查看同站风格的完整示例；也可用任意静态服务器预览。所有样式、脚本、插图和示例图片在包内，不依赖 CDN。页面中的站点导航与下载链接仅在主动点击时访问线上网站。离线时复制按钮可能需要手动复制，页面会提供提示。

## 接入现有工具模板

1. 复制 assets/feedback/ 的 SVG；常规空态显示 120×90，手机 96×72，配相邻标题、短说明与真实动作；有同义说明时 img alt 为空。
2. 引入 feedback-motion.css 和 defer 的 feedback-motion.js；CSS可独立保留静态反馈，脚本提供可见性与减动处理。
3. 按 feedback-states.md 的 data-ft-activity / data-ft-reveal / data-ft-parallax 契约，接自己的业务状态。默认内容可见，入场由实际状态变化触发，不等待脚本显示整页。
4. 使用 window.FunToolkitFeedback 的 enter / exit / replay / setPaused / init / refresh / destroy；退出含焦点内容前先将焦点交回有效入口。
5. Spinner未知进度，progress真实完成量，图片load/error由业务处理。不要复制示例数字、计时器或演示反馈作为生产任务。

feedback-states.css / .js 与 index.html 仅负责展示页，不需要整包接入生产。tool-page-framework.css是展示页沿用的站点基础样式；可复用的加载、骨架、占位、出入场和视差在 feedback-motion.css / .js。规范参数、能力边界与验收见 feedback-states.md。

本包不会自动修改三个正式工具，不提交请求、不计数、不提供生成或编码。SVG为原生可编辑矢量UI图形，文字均在图外；示例预览为本站已有的480px WebP插画。

可选自检：安装 Node 后在本目录运行 `node check.cjs`。它使用标准库执行真实动效脚本，验证生命周期、减少动画、入退场竞态与降级；视觉仍需浏览器验收。
