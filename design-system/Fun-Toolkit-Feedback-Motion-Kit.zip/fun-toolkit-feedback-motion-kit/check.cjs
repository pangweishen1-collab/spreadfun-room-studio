/* Node standard-library check of the real browser primitive, using small platform doubles. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.resolve(__dirname,'feedback-motion.js'),'utf8');

class Target {
  constructor() { this.events = new Map(); }
  addEventListener(type, fn) { if (!this.events.has(type)) this.events.set(type,new Set());this.events.get(type).add(fn); }
  removeEventListener(type, fn) { this.events.get(type)?.delete(fn); }
  fire(type, event = {}) { for (const fn of this.events.get(type) || []) fn(event); }
}
class Element extends Target {
  constructor(dataset = {}) {
    super();this.nodeType = 1;this.dataset = dataset;this.hidden = false;this.inert = false;this.children = [];
    this.box = {left:0,top:10,right:200,bottom:210,width:200,height:200};this.styles = {};
    this.style = {setProperty:(key,value) => { this.styles[key] = value; }};
    this.animations = [];
  }
  getBoundingClientRect() { return this.box; }
  querySelectorAll(selector) { return selector === '[data-ft-layer]' ? this.children : []; }
  animate(frames, options) {
    let finish, reject;
    const animation = {frames,options,cancelled:false,finished:new Promise((a,b) => { finish = a;reject = b; }),
      finish:() => finish(),cancel() { this.cancelled = true;reject(new Error('cancelled')); }};
    this.animations.push(animation);return animation;
  }
}
function platform({intersection = true, motion = false, fine = true, raf = true} = {}) {
  const document = new Target();const window = new Target();
  document.readyState = 'complete';document.hidden = false;
  const activity = new Element({ftActivity:''});
  const pointer = new Element({ftParallax:'pointer'});pointer.children = [new Element()];
  const scroll = new Element({ftParallax:'scroll'});scroll.children = [new Element()];
  const reveal = new Element({ftReveal:'rise'});
  document.querySelectorAll = selector => selector === '[data-ft-activity]' ? [activity] : selector === '[data-ft-parallax]' ? [pointer,scroll] : [];
  document.getElementById = id => id === 'reveal' ? reveal : null;
  const reduced = new Target();reduced.matches = motion;
  const pointerMedia = new Target();pointerMedia.matches = fine;
  window.matchMedia = query => query.includes('reduced-motion') ? reduced : pointerMedia;
  window.innerHeight = 800;window.innerWidth = 1200;
  let nextFrame = 1;const frames = new Map();
  if (raf) {
    window.requestAnimationFrame = fn => { const id = nextFrame++;frames.set(id,fn);return id; };
    window.cancelAnimationFrame = id => frames.delete(id);
  }
  const observations = [];
  if (intersection) window.IntersectionObserver = class {
    constructor(callback) { this.callback = callback;observations.push(this); }
    observe() {} disconnect() { this.disconnected = true; }
  };
  vm.runInNewContext(source,{window,document,console});
  return {api:window.FunToolkitFeedback,document,window,activity,pointer,scroll,reveal,reduced,pointerMedia,frames,observations,
    flush() { const batch = [...frames.values()];frames.clear();batch.forEach(fn => fn()); },
    intersect(target,visible) { observations[0].callback([{target,isIntersecting:visible}]); }};
}

(async () => {
  const p = platform();
  assert.equal(p.activity.dataset.ftRunning,'true','visible loader runs');
  assert.equal(p.frames.size,0,'no persistent idle RAF');
  p.pointer.fire('pointermove',{clientX:900,clientY:900,pointerType:'mouse'});
  p.pointer.fire('pointermove',{clientX:901,clientY:901,pointerType:'mouse'});
  assert.equal(p.frames.size,1,'pointer events share one scheduled frame');p.flush();
  assert.equal(p.pointer.children[0].styles['--ft-parallax-x'],'6.00px','pointer x capped at 6');
  assert.equal(p.pointer.children[0].styles['--ft-parallax-y'],'6.00px','pointer y capped at 6');
  assert.equal(p.frames.size,0,'no continuous RAF after pointer update');
  p.intersect(p.activity,false);p.intersect(p.pointer,false);p.flush();
  assert.equal(p.activity.dataset.ftRunning,'false','offscreen loader pauses');
  assert.equal(p.pointer.children[0].styles['--ft-parallax-x'],'0.00px','offscreen pointer resets');
  p.intersect(p.activity,true);p.flush();
  assert.equal(p.activity.dataset.ftRunning,'true','reenter resumes loader');
  p.window.fire('scroll');assert.equal(p.frames.size,1);
  p.document.hidden = true;p.document.fire('visibilitychange');
  assert.equal(p.frames.size,0,'background cancels queued RAF');
  assert.equal(p.activity.dataset.ftRunning,'false','background pauses loader');
  assert.equal(p.scroll.children[0].styles['--ft-parallax-y'],'0.00px','background resets parallax');
  p.intersect(p.activity,true);p.window.fire('scroll');
  assert.equal(p.frames.size,0,'background events cannot enqueue another RAF');
  p.document.hidden = false;p.document.fire('visibilitychange');
  assert.equal(p.activity.dataset.ftRunning,'true');
  p.api.setPaused(true);assert.equal(p.activity.dataset.ftRunning,'false','explicit pause works');
  p.api.setPaused(false);assert.equal(p.activity.dataset.ftRunning,'true','explicit resume works');

  const exit = p.api.exit(p.reveal);const oldExit = p.reveal.animations.at(-1);
  assert.equal(oldExit.options.duration,120);assert.equal(p.reveal.hidden,false,'not hidden before exit finishes');
  assert.equal(p.reveal.inert,true,'exit immediately removes pointer and Tab interaction');
  const enter = p.api.enter(p.reveal);const newEnter = p.reveal.animations.at(-1);
  assert.equal(p.reveal.inert,false,'entry cancelling exit restores original interaction state');
  assert.equal(oldExit.cancelled,true);assert.equal(newEnter.options.duration,180);
  assert.equal(newEnter.frames[0].transform,'translateY(6px)');
  oldExit.finish();await Promise.resolve();assert.equal(p.reveal.hidden,false,'stale exit cannot hide new entry');
  newEnter.finish();assert.equal(await enter,true);assert.equal(await exit,false);assert.equal(p.reveal.hidden,false);
  const finishedExit = p.api.exit(p.reveal);p.reveal.animations.at(-1).finish();
  assert.equal(await finishedExit,true);assert.equal(p.reveal.hidden,true,'finished exit sets hidden');
  assert.equal(p.reveal.inert,false,'finished exit restores original inert once hidden');
  p.reveal.dataset.ftReveal = 'fade';const fade = p.api.enter(p.reveal);
  assert.equal(p.reveal.animations.at(-1).frames[0].transform,'translateY(0)');
  p.reveal.animations.at(-1).finish();await fade;
  const pendingExit = p.api.exit(p.reveal);p.reduced.matches = true;p.reduced.fire('change');
  assert.equal(await pendingExit,false);assert.equal(p.reveal.hidden,true,'motion change settles requested exit');
  assert.equal(p.reveal.inert,false,'motion change restores original inert');
  assert.equal(p.activity.dataset.ftRunning,'false','reduced motion pauses continuous animations');
  const count = p.reveal.animations.length;
  assert.equal(await p.api.enter(p.reveal),true);assert.equal(p.reveal.hidden,false);
  assert.equal(p.reveal.animations.length,count,'reduced entry has no animation');
  p.reveal.inert = true;
  await p.api.exit(p.reveal);await p.api.enter(p.reveal);
  assert.equal(p.reveal.inert,true,'reduced exit/entry preserves business inert=true');
  p.reduced.matches = false;p.reduced.fire('change');p.pointerMedia.matches = false;p.pointerMedia.fire('change');
  const inertExit = p.api.exit(p.reveal);const inertEnter = p.api.enter(p.reveal);
  p.reveal.animations.at(-1).finish();await inertEnter;await inertExit;
  assert.equal(p.reveal.inert,true,'animated exit/entry preserves business inert=true');
  p.reveal.inert = false;const destroyExit = p.api.exit(p.reveal);
  assert.equal(p.reveal.inert,true);
  p.pointer.fire('pointermove',{clientX:100,clientY:100,pointerType:'touch'});p.flush();
  assert.equal(p.pointer.children[0].styles['--ft-parallax-x'],'0.00px','coarse pointer has no parallax');
  p.api.destroy();assert.equal(p.activity.dataset.ftRunning,'false');
  await destroyExit;assert.equal(p.reveal.inert,false,'destroy restores original inert');
  assert.equal(p.frames.size,0);assert.equal(p.observations[0].disconnected,true);
  assert.equal([...p.window.events.values()].every(set => !set.size),true,'window listeners cleaned');
  p.api.init();assert.equal(p.activity.dataset.ftRunning,'true','can explicitly reinitialize');p.api.destroy();

  const fallback = platform({intersection:false,raf:false});
  fallback.activity.box.top = 900;fallback.activity.box.bottom = 1100;fallback.window.fire('scroll');
  assert.equal(fallback.activity.dataset.ftRunning,'false','geometry fallback detects offscreen');
  fallback.scroll.box.top = -10000;fallback.scroll.box.bottom = 200;fallback.api.refresh();
  assert.equal(fallback.scroll.children[0].styles['--ft-parallax-y'],'12.00px','scroll displacement capped at 12');
  fallback.reveal.animate = undefined;
  await fallback.api.exit(fallback.reveal);assert.equal(fallback.reveal.hidden,true,'no WAAPI degrades to immediate exit');
  const noInert = new Element({ftReveal:'rise'});delete noInert.inert;
  await fallback.api.exit(noInert);
  assert.equal(noInert.hidden,true,'unsupported inert degrades to immediate hidden exit');
  assert.equal(noInert.animations.length,0,'never leaves unsupported inert content fading but interactive');
  fallback.api.destroy();
  const reduced = platform({motion:true});assert.equal(reduced.activity.dataset.ftRunning,'false');reduced.api.destroy();
  console.log('Passed: real primitive states, pause/resume, reduced motion, offscreen/background, one-frame scheduling, parallax caps, quick exit-enter race, cleanup and platform fallbacks.');
})().catch(error => { console.error(error);process.exitCode = 1; });
